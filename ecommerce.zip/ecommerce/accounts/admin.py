from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Account

class AccountAmin(UserAdmin):
    list_display = ('email', 'first_name', 'last_name', 'username', 'last_login', 'date_joind', 'is_active' )
    list_display_link = ('email', 'first_name', 'last_name')
    readonly_fields = ('last_login', 'date_joind')
    ordering = ('-date_joind',)

    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()
# Register your models here.
admin.site.register(Account, AccountAmin)
